ITEM.name = "Makeshift Repair Kit"
ITEM.desc = "A one-use makeshift repair kit that includes the bare essentials to repair weaponry and equipment back to working condition.\n\nYou'll need to find a professional for better quality repairs."
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.uniqueID = "repairkit_makeshift"

ITEM.price = 25

if (CLIENT) then
	function ITEM:paintOver(item, w, h)
		draw.SimpleText("1/1", "DermaDefault", 5, h-5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end